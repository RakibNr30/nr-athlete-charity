<div class="btn-group">
    <a href="{{ route('backend.cms.rice.edit', [$data->id]) }}" type="button" class="btn btn-default">
        <i class="fas fa-pen"></i>
    </a>
</div>
