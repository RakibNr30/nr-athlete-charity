<?php

return [

    'total_athlete' => 'Total Athlete',
    'total_donation' => 'Total Donation',
    'rice_price' => 'Rice Price (per kg)',

    'donate' => 'Donate',
    'donate_now' => 'Donate Now',
    'raise_your_hand' => 'Raise your hand to right place or foundation',
    'donate_for_all' => 'Donate for all',
    'card_details' => 'Card Details',
    'pay_now' => 'Pay Now',
    'pay_now_with_paypal' => 'Pay now with PayPal',

    'calories' => 'Calories',
    'rice' => 'Rice',
    'popular_cases' => 'Popular Cases',

];
