<?php

return [

    'about_us' => 'About Us',
    'about' => 'About',
    'vision' => 'Vision',
    'our_goals' => 'Our Goals',
    'total_athlete' => 'Total Athlete',
    'total_donation' => 'Total Donation',
    'rice_price' => 'Rice Price (per kg)',

];
