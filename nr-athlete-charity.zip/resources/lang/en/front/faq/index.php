<?php

return [
    'popular_cases' => 'Popular Cases'
];
