<?php

return [

    'contact' => 'Contact',
    'get_in_touch' => 'Get In Touch',
    'dont_hesited_to_contact_us' => 'Don\'t Hesitate To Contact Us',
    'phone_number' => 'Phone Number',
    'email_address' => 'E-mail Address',
    'our_location' => 'Our Location',
    'send_message' => 'Send Message',
    'feel_free_to_write_us_message' => 'Feel Free To Write Us Message',
    'your_name' => 'Your Name',
    'your_location' => 'Your Location',
    'message' => 'Message'
];
