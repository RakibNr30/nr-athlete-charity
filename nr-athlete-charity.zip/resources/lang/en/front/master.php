<?php

return [

    'donate_now' => 'Donate Now',
    'privacy_policy' => 'Privacy Policy',

    'my_profile' => 'My Profile',
    'donation_history' => 'Donation History'
];
