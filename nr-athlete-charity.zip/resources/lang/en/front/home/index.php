<?php

return [

    'total_athlete' => 'Total Athlete',
    'total_donation' => 'Total Donation',
    'rice_price' => 'Rice Price (per kg)',
    'popular_cases' => 'Popular Cases',
    'view_all' => 'View All',
    'popular_charity_causes_around_the_world' => 'Popular Charity Causes Around the world',
    'donate_now' => 'Donate Now',
    'latest_news' => 'Latest News',
    'get_our_every_news_and_blog' => 'Get Our Every News & Blog',
];
