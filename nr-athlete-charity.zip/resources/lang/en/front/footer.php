<?php

return [
    'about_us' => 'About us',
    'cases' => 'Cases',
    'news' => 'News',
    'team' => 'Team',
    'faq' => 'Faq',
    'contact' => 'Contact',

    'get_in_touch' => 'Get In Touch',
    'location' => 'Location',
    'email_us' => 'Email Us',
    'phone' => 'Phone'
];
