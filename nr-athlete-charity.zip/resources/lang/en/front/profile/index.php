<?php

return [

    'profile' => 'Profile',
    'personal_info' => 'Personal Info',
    'donation_history' => 'Donation History'

];
