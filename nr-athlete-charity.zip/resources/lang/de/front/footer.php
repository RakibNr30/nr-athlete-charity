<?php

return [
    'about_us' => 'Über uns',
    'cases' => 'Projekte',
    'news' => 'News',
    'team' => 'Team',
    'faq' => 'Faq',
    'contact' => 'Kontakt',

    'get_in_touch' => 'Kontakt',
    'location' => 'Standort',
    'email_us' => 'E-Mail',
    'phone' => 'Telefon'
];
