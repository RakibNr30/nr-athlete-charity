<?php

return [

    'total_athlete' => 'Sportler*innen gesamt ',
    'total_donation' => 'Spenden gesamt',
    'rice_price' => 'Reispreis (pro kg)',
    'popular_cases' => 'Charity Projekte',
    'view_all' => 'Alle anzeigen',
    'popular_charity_causes_around_the_world' => 'Eure Spenden gehen diesen Monat an eines 	
	der folgenden Projekte:',
    'donate_now' => 'Jetzt spenden',
    'latest_news' => 'Neuesten Nachrichten',
    'get_our_every_news_and_blog' => 'Erhalten Sie unsere News & Blog',

];
