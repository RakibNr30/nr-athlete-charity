<?php

return [
    'donate_now' => 'Jetzt spenden',
    'privacy_policy' => 'Datenschutz',

    'my_profile' => 'Profil',
    'donation_history' => 'Mein Spendenverlauf'
];
