<?php

return [

    'profile' => 'Profil',
    'personal_info' => 'Persönliche Daten',
    'donation_history' => 'Mein Spendenverlauf'

];
