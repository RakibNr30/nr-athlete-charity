<?php

return [

    'about_us' => 'Über uns',
    'about' => 'Über',
    'vision' => 'Unsere Vision',
    'our_goals' => 'Unsere Ziele',
    'total_athlete' => 'Sportler*innen gesamt ',
    'total_donation' => 'Spenden gesamt',
    'rice_price' => 'Reispreis (pro kg)',

];
