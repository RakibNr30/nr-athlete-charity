<?php

return [

    'contact' => 'Kontakt',
    'get_in_touch' => 'Kontakt',
    'dont_hesited_to_contact_us' => 'Bei Fragen erreicht ihr uns unter:',
    'phone_number' => 'Telefon',
    'email_address' => 'E-Mail Adresse',
    'our_location' => 'Anschrift',
    'send_message' => 'Nachricht schreiben',
    'feel_free_to_write_us_message' => 'Schreib uns eine Nachricht',
    'your_name' => 'Dein Name',
    'your_location' => 'Anschrift',
    'message' => 'Nachricht'
];
