<?php

return [

    'total_athlete' => 'Sportler*innen gesamt ',
    'total_donation' => 'Spenden gesamt',
    'rice_price' => 'Reispreis (pro kg)',

    'donate' => 'Spenden',
    'donate_now' => 'Jetzt spenden',
    'raise_your_hand' => 'Wähle aus, für welches Projekt du spenden möchtest',
    'donate_for_all' => 'Meine Spende auf alle Projekte verteilen',
    'card_details' => 'Kreditkarteninformationen',
    'pay_now' => 'Jetzt spenden',
    'pay_now_with_paypal' => 'Mit PayPal spenden',

    'calories' => 'Kalorien',
    'rice' => 'Reis',
    'popular_cases' => 'Projekte',

];
