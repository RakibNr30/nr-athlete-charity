<footer class="footer-area black-bg pos-rel pt-50 pb-50" style="background-image:url({{ asset('front/img/bg/02.html') }})">
    <div class="container">
        <div class="copy-right-area copy-area-02">
            <div class="row align-items-center">
                <div class="col-xl-12">
                    <div class="copyright text-center">
                        <p>Copyright © 2021 | All Rights Reserved <span>{{ $globalSite->title ?? 'Athlete Charity' }}</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>